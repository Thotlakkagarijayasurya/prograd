<!DOCTYPE html>
<html>
    <head>
        <title>document</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    </head>
    <body>
        <table>
            <thead>
                <tr>
                    <th>Centre</th>
                    <th>Registered</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "covid_vaccination";

                $conn = mysqli_connect($servername,$username,$password,$dbname);
                $sql = "SELECT * FROM vaccination_centres";
                $result=mysqli_query($conn, $sql);

                if(mysqli_num_rows($result)>0){
                    while($row=mysqli_fetch_assoc($result)) {
                        echo "<tr>
                        <td>" . $row["centre"] . "</td>
                        <td>" . $row["registered"] . "</td>
                        </tr>";
                    }
                }
                ?>
            </tbody>
        </table>
    </body>
</html>


