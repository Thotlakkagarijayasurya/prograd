<?php
print_r($_POST);
/*if(isset($_POST['signupbutton']))
{
$email = $_POST['uemail'];
$password = $_POST['upassword'];
$confirm_password = $_POST['uconfirmpassword'];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "covid_vaccination";
$conn = mysqli_connect($servername,$username,$password,$dbname);
if(mysqli_connect_error()) {
    die('Connect Error('.mysqli_connect_errno().')'.mysqli_connect_error());
} else {
        
        $INSERT = "INSERT INTO users(username,passwrd) values('strings','hello')";
        if(mysqli_query($conn, $INSERT)){
        echo "<script>alert('Account created successfully')</script>";
        }
        else{
            echo "<script>alert('Already have account')</script>";
            return;
        }
    }
    mysqli_close($conn);
}*/
?>