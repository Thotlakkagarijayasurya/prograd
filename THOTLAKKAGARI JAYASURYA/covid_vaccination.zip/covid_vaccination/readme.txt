admin login
username-Admin123@gmail.com
password-admin@123
tables
1.candidate details(name,phone,email,date,time,location)
2.vaccination_centres(centre,registered)
3.users(username,passwrd)